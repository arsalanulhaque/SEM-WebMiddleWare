//THIS IS THE MOST IMPORTANT FILE OF THIS PROJECT
//THIS FILE HAS ALL THE IMPLEMENTATION FOR SOCKET.IO

const logger = require('../Utilities/Logger.js')
const helper = require('../Utilities/Helper.js')
const ClientSession = require('../BLL/ClientSession.js')
const dataController = require('./DataController')
const dtmController = require('./SemDataTransferMonitor/DTMController.js')
const disableClientNotification = require('./DisableClientNotification.js')

//let clientsCount = 0; //counter for connected users 
//let clientsConnectionPool = [] //manage clients connections
let io = null;
let socket = null
const ClientSessionInstance = ClientSession.ClientSession.getInstance()



//Whenever someone connects this gets executed
exports.SocketServer = (IO, objSelfInstance) => {
    try {
        io = IO;
        //This event fires when a new client connects
        io.on('connection', async (_socket) => {
            socket = _socket;

            const getClients = () => {
                let adminSocket = ClientSessionInstance.getClientSessions('AdminPanel')[0]?.socketID
                if (adminSocket !== undefined)
                    io.to(adminSocket).emit('ConnectedClients', ClientSessionInstance.excludeClientSessions('AdminPanel'))
            }

            //This event fires when a client sends request to register
            //Every client should call this event to register it self
            //This is important to maintain clients connection
            //data.dashboardID is basically related to control_id of react component
            //Based on data.dashboardID we manage sockets connections in clientConnections array
            socket.on('registerClient', async function (data) {
                try {
                    ClientSessionInstance.addClientSession(data)
                    console.log(`No of client sessions: ${ClientSessionInstance.getClientCount()}`)
                    //Adding  client connection to pool
                    // clientsConnectionPool.push(data)
                    logger.info("SocketIO.js", "registerClient", 'New connection from ' + data.dashboardID + ' connected having socket id: ' + data.socketID);
                    logger.info("SocketIO.js", "registerClient", 'No of clients connected: ' + ClientSessionInstance.getClientCount());
                    getClients()
                }
                catch (error) {
                    logger.error("SocketIO.js", "registerClient", error);
                }
            });

            socket.on('create', function (room) {
                socket.join(room);
            });

            //This event fires when a client sends request to unregister
            socket.on('unregisterClient', function (data) {
                try {
                    logger.info("SocketIO.js", "unregisterClient", 'Client disconnecting from ' + data.dashboardID)
                    clientsConnectionPool.pop(data);
                }
                catch (error) {
                    logger.error("SocketIO.js", "unregisterClient", error);
                }
            });

            //This event fires Whenever someone disconnects for any reason
            socket.on('disconnect', function (data) {
                try {
                    logger.info("SocketIO.js", "disconnect", 'A user disconnected from: ' + data);
                    //  socket.manager.onClientDisconnect(socket.id);// --> endless loop with this disconnect event on server side
                    ClientSessionInstance.removeClientBySocketID(socket.id)
                    // let filterSockets = clientsConnectionPool.filter((item) => { return item.socketID === socket.id });
                    // if (filterSockets !== undefined) {
                    //     if (filterSockets.length > 0) {
                    //         filterSockets.map(instance => {
                    //             clientsConnectionPool.pop(instance);
                    //         })
                    //     }
                    // }
                    socket.disconnect(); //--> same here
                    getClients()
                }
                catch (error) {
                    logger.error("SocketIO.js", "disconnect", error);
                }
            });

            //This event fires when client reload button is pressed from index.html
            socket.on("reloadClients", function () {
                io.sockets.emit('reloadBrowser', 'Reload initiated by IS team!');
            })

            //This event fires when URL Update button is pressed from index.html
            socket.on("updateUrl", function (data) {
                console.log('Number of clients: ', socket.rooms)
                io.sockets.in(data.room).emit('updateClientUrl', data.url);
            })

            //This event fires when Global Date Filters changed from SEM Data Transfer Monitor App
            socket.on("updateDTMSession", function (data) {
                ClientSessionInstance.updateClientSession(data)
                dtmController.Run(objSelfInstance)
            })

            //This event fires when Reset button is pressed on Data Transfer Details Screen under SEM Data Transfer Monitor App
            //Enables to push updates so to restart the routine sync
            socket.on("RemoveFilters", function (data) {
                disableClientNotification.removeClient(data.socketID, data.disbaleNotificationEvent)
            })

            //This event fires when Trigger SNO Untransferred button is clicked from SEM Data Transfer Monitor App
            socket.on("TriggerUntransferredSNo", function (data) {
                dtmController.TriggerUntransferredSNo(objSelfInstance, data)
            })

            // This event fires Whenever someone disconnects for any reason
            socket.on('DisconnectClient', function (data) {
                try {
                    logger.info("SocketIO.js", "DisconnectClient", 'Force disconnect from: ' + data.socketID);
                    ClientSessionInstance.removeClientBySocketID(data.socketID)
                    //socket.disconnect();
                    io.sockets.sockets.forEach(element => {
                        if (data.socketID === element.id) {
                            element.disconnect()
                        }
                    });
                    //io.sockets.sockets[data.socketID].disconnect();

                    getClients()
                }
                catch (error) {
                    logger.error("SocketIO.js", "disconnect", error);
                }
            });

        });
    }
    catch (error) {
        logger.error("SocketIO.js", "SocketServer", error);
    }
}

exports.IsClientConnected = () => {
    if (ClientSessionInstance?.getClientCount() > 0)
        return true
    else
        return false;
}

exports.NotifyClient = (dashboardName, eventName, response) => {
    if (dashboardName === 'DataTransferMonitor')
        notificationToDataTransferMonitor(dashboardName, eventName, response)
    else
        notification(dashboardName, eventName, response)
}

const notificationToDataTransferMonitor = (dashboardName, eventName, response) => {

    // if (disableClientNotification.isClientDisabled(response.socketID, eventName) === false) {
    // console.log(`Notify Client ${dashboardName}: session: ${response.session.sessionID} socket: ${response.session.socketID} - ${eventName}`)
    //Sending error out to specified client
    if (response?.error) {
        io.to(response.socketID).emit('responseError', response);
    }
    //Sending data out to specified client 
    io.to(response.session.socketID).emit(eventName, response);
    // } else {
    //     console.log(`Disabled Client Event ${objSocket.dashboardID}: ${objSocket.socketID} - ${eventName}`)
    // }
}

const notification = (dashboardName, eventName, response) => {
    if (!this.IsClientConnected())
        return;

    ClientSessionInstance.getClientSessions(dashboardName).forEach(objSocket => {
        if (objSocket.dashboardID === dashboardName) {
            // console.log(`Notify Client ${objSocket.dashboardID}: ${objSocket.socketID} - ${eventName}`)
            //Sending error out to specified client
            if (response?.error) {
                io.to(objSocket.socketID).emit('responseError', response);
            }
            //Sending data out to specified client 
            else {
                io.to(objSocket.socketID).emit(eventName, response);
            }
        }
    })
}
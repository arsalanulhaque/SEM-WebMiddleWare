let clients = []

exports.addClientToDisable = (socketID, eventNameToDisable) => {
    clients.push({ socketID: socketID, eventName: eventNameToDisable })
}

exports.removeClient = (socketID, eventName) => {
    let ind = clients.findIndex(cl => cl.socketID === socketID && cl.eventName === eventName)
    clients.pop(ind)
}

exports.isClientDisabled = (socketID, eventName) => {
    let clientsCount = (clients.filter(cl => cl.socketID === socketID && cl.eventName === eventName)).length
    return clientsCount > 0 ? true : false
}
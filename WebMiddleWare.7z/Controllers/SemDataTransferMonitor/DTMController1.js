var mappings = require('../../Configs/Mappings.js');
var callee = require('../../DAL/ServiceCaller.js');
var helper = require('../../Utilities/Helper.js');
var logger = require('../../Utilities/Logger');
var convert = require('xml-js');

const ClientSession = require('../../BLL/ClientSession.js')

const ClientSessionInstance = ClientSession.ClientSession.getInstance()

const getUrl = (session, apiKey) => {
    let baseUrl = `${mappings.GetAPIByKey(apiKey)}`
    let urlParam = apiKey === 'MiiJHWorksQueueCount' ?
        `&startDate=${helper.setDate(session.startDate, 0, true)}&endDate=${helper.setDate(session.endDate, session.filterName === 'today' ? 1 : 0, true)}` :
        // `&Param.1=${helper.setDate('2023/01/01', 0, true)}&Param.2=${helper.setDate('2023/07/10', session.filterName === 'today' ? 1 : 0, true)}`
        `&Param.1=${helper.setDate(session.startDate, 0, true)}&Param.2=${helper.setDate(session.endDate, session.filterName === 'today' ? 1 : 0, true)}`
    console.log(apiKey, baseUrl + urlParam)
    return baseUrl + urlParam
}

exports.Run = async (socketInstance) => {
    try {
        let lstSessions = ClientSessionInstance.getClientSessions('DataTransferMonitor')
        lstSessions.forEach(session => {
            session.events.forEach(event => {
                let url = getUrl(session, event)
                // console.log(url)
                logger.info("DTMController.js", `Run`, `Requesting data from  ${url}`)
                callee.ServiceCaller(url, (response) => {
                    let output = getParsedData(response, session)
                    //Calling Socket Event to Notify Client
                    socketInstance.NotifyClient('DataTransferMonitor', event, output)
                });
            })
        })
    }
    catch (error) {
        logger.error("DTMController.js", "GetMiiJHWorksQueueCount", error);
    }
}

exports.TriggerUntransferredSNo = async (socketInstance, data) => {
    console.log(data.inputParams)
    let url = `${mappings.GetAPIByKey('TriggerSerialNo')}&workOrderNumber=${data.inputParams.WorkOrder}&materialNumber="${data.inputParams.PartNumber}"`

    logger.info("DTMController.js", `TriggerUntransferredSNo`, `Triggereing Untransferred Serial Number  ${url}`)
    callee.ServiceCaller(url, (response) => {
        let output = getParsedData(response, data)
        //Calling Socket Event to Notify Client
        socketInstance.NotifyClient('DataTransferMonitor', 'ResponseToTriggerUntransferredSNo', output)
    });
}

var getParsedData = (response, session) => {
    try {
        let result = {
            data: null,
            error: false,
            errorMsg: '',
            errorSource: '',
            session: session
        }

        //Set Error Status in Response Object
        if (response?.isAxiosError) {
            result.error = true
            result.errorMsg = `${response.response.statusText}!`
            result.errorSource = response.request.host + response.request.path
            result.code = response.response.status
            return result
        }
        if (response?.headers['content-type'] !== 'application/json' && response?.headers['content-type'] !== 'text/json') {
            result.error = true
            result.errorMsg = response.data.Rowsets.FatalError || 'Invalid data format!'
            result.errorSource = response.request.host + response.request.path
            return result
        }
        //Set Data Error
        if (response?.data?.Rowsets?.Rowset?.length > 0) {
            if (response?.data?.Rowsets?.Rowset[0]?.Row === undefined && response?.data?.Rowsets?.Rowset[1]?.Row === undefined) {
                result.data = []
                result.error = false
                result.errorMsg = 'No data recieved from API!'
                result.errorSource = response.request.path
                return result
            }
        }

        //Set Fatal Error
        if (response?.data?.Rowsets?.FatalError?.length > 0) {
            result.data = []
            result.error = true
            result.errorMsg = response?.data?.Rowsets?.FatalError
            result.errorSource = response.request.path
            return result
        }
        //Set Success in Response Object
        if (typeof response.data === 'string') {
            // let o = JSON.parse(convert.xml2json(response.data, { compact: true, spaces: 0 }))
            result.data = response.data
        } else {
            result.data = processData(response?.data?.Rowsets?.Rowset)
        }
        return result
    }
    catch (error) {
        logger.error("DTMController.js", "getParsedData", error);
        logger.error("DTMController.js", "getParsedData", response.request.path);
    }
}

var processData = (data) => {
    var joinResults = []
    data?.map((rowSet, index) => {
        if (index === 0) {
            joinResults = rowSet?.Row === undefined ? joinResults : rowSet?.Row
        }
        else {
            joinResults = rowSet?.Row === undefined ? joinResults : joinResults.concat(rowSet.Row)
        }
    })
    return joinResults
}

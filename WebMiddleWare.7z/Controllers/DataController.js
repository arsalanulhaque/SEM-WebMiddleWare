//THIS FILE HAS ALL THE CONTROLLERS OR MIDDLEWARE FUNCTIONS TO MAKE HTTPS REQUEST
//AND PROCESS THE RESPONSE FOR SEM DATA TRANSFER MONITOR

var mappings = require('../Configs/Mappings.js');
var callee = require('../DAL/ServiceCaller.js');
var authentication = require('../BLL/Authentication');
var logger = require('../Utilities/Logger');

const auth = new authentication.Authentication();

exports.GenerateToken = async () => {
    try {
        auth.RequestToken();
    }
    catch (error) {
        logger.error("DataController.js", "GenerateToken", error);
    }
}

exports.GetPartsList = async (stationId, callback) => {
    try {
        let url = `${mappings.GetAPIByKey("partsList")}${stationId}`
        logger.info("DataController.js", "GetPartsList", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetPartsList", error);
    }
}

exports.GetLastPartNumber = async (stationId, callback) => {
    try {
        let url = `${mappings.GetAPIByKey("lastPartNumber")}${stationId}`
        logger.info("DataController.js", "GetLastPartNumber", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetLastPartNumber", error);
    }
}

exports.GetChartsData = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("chartsData")}`
        logger.info("DataController.js", "GetChartsData", `Requesting data from  ${url}`)
        await callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetChartsData", error);
    }
}

exports.GetCellStats = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("cellStats")}`
        logger.info("DataController.js", "GetCellStats", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetCellStats", error);
    }
}

exports.GetArrears = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("arrears")}`
        logger.info("DataController.js", "GetArrears", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetArrears", error);
    }
}

exports.GetOutputVsBookings = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("outputVsBookings")}`
        logger.info("DataController.js", "GetOutputVsBookings", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetArrears", error);
    }
}

exports.GetFtprRtpy = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("ftprRtpy")}`
        logger.info("DataController.js", "GetFtprRtpy", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(getParsedData(response))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetArrears", error);
    }
}

exports.GetUserList = async (callback) => {
    try {
        let url = `${mappings.GetAPIByKey("cellStats")}`
        logger.info("DataController.js", "GetUserList", `Requesting data from  ${url}`)
        callee.ServiceCaller(url, function (response) {
            callback(removeDuplicatesEntries(getParsedData(response)))
        });
    }
    catch (error) {
        logger.error("DataController.js", "GetUserList", error);
    }
}


var getParsedData = (response) => {
    try {
        let result = {
            data: null,
            error: false,
            errorMsg: '',
            errorSource: ''
        }

        //Set Error Status in Response Object
        if (response.isAxiosError) {
            result.error = true
            result.errorMsg = `${response.response.statusText}!`
            result.errorSource = response.request.host + response.request.path
            result.code = response.response.status
        }
        else if (response.headers['content-type'] !== 'application/json' && response.headers['content-type'] !== 'text/json') {
            result.error = true
            result.errorMsg = response.data.Rowsets.FatalError || 'Invalid data format!'
            result.errorSource = response.request.host + response.request.path
        }
        //Set Data Error
        else if (response.data.Rowsets.Rowset[0].Row === undefined) {
            result.error = true
            result.errorMsg = 'No data recieved from API!'
            result.errorSource = response.request.path
        }
        else {
            //Set Success in Response Object
            result.data = processData(response.data.Rowsets.Rowset)
        }

        return result
    }
    catch (error) {
        logger.error("DataController.js", "getParsedData", error);
        logger.error("DataController.js", "getParsedData", response.request.path);
    }
}

var processData = (data) => {
    var joinResults = []
    data.map((rowSet, index) => {
        if (index === 0) {
            joinResults = rowSet.Row
        }
        else {
            joinResults = joinResults.concat(rowSet.Row)
        }
    })
    return joinResults
}

var removeDuplicatesEntries = (response) => {
    try {

        let usersData = []
        if (response.data !== null || response.data !== undefined) {
            response.data.map((objActualData, ind) => {
                let flag = false
                //ignore cell where user is unavailable
                if (objActualData.USER_NAME !== 'NA') {
                    //check username doesn`t exists
                    usersData.map((objUserData, ind) => {
                        if (objUserData.USER_NAME === objActualData.USER_NAME)
                            flag = true
                    })
                    //if user not found 
                    if (!flag)
                        //add user to usersData
                        usersData.push({
                            Line_Number: objActualData.Line_Number, USER_NAME: objActualData.USER_NAME,
                            DATE_FROM: objActualData.DATE_FROM, INVALID_LOGIN: objActualData.INVALID_LOGIN
                        })
                }
            })
            return { data: usersData }
        }
        else
            return { data: usersData }
    }
    catch (error) {
        logger.error("DataController.js", "removeDuplicatesEntries", error);
    }
}

exports.clock = () => {
    try {
        var dateTime = new Date();
        dateTime = dateTime.toLocaleDateString() + ' ' + dateTime.toLocaleTimeString()
        return dateTime;
    }
    catch (error) {
        logger.error("DataController.js", "clock", error);
    }
}
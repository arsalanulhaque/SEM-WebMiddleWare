exports.setDate = (date, daysAddorSub = 0, convertToDate = true) => {
    date = new Date(date)
    if (daysAddorSub !== 0) date.setDate(date.getDate() + daysAddorSub)
    return convertToDate ? (date.toISOString().slice(0, 10)) : date
}
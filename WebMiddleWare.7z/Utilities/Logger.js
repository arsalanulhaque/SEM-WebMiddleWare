//THIS IS A UTILITY CLASS FOR LOGGING ALL THE MESSAGES TO CONSOLE
//THIS FILE CAN ALSO BE USED TO STORE LOGS IN TEXT FILES

const fs = require('fs');

const enumMessageType = {
    Error: "error",
    Log: "log",
    Info: "info"
}

const getLogFile = () => {
    let date = new Date()
    date = `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`
    return `log ${date}.txt`
}

const writeToFile = (type, file, method, error) => {
    let transaction = '';
    let date = new Date()
    let dateTime = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
    switch (type) {
        case 'error':
            transaction = `Error MESSAGE ----->>>>>> FROM (${file}) ON (${method}) AT: ${dateTime} \n ${error}  \n`
            break;
        case 'log':
            transaction = `LOG MESSAGE ----->>>>>> FROM (${file}) ON (${method}) AT: ${dateTime} \n ${error}  \n`
            break;
        case 'info':
            transaction = `INFO MESSAGE ----->>>>>> FROM (${file}) ON (${method}) AT: ${dateTime} \n ${error}  \n`
            break;
    }

    fs.appendFile(getLogFile(), transaction, function (err) {
        if (err) throw err;
    });

    return transaction;
}

exports.error = (file, method, err) => {
    let log = writeToFile(enumMessageType.Error, file, method, err)
    console.error(log);
}

exports.log = (file, method, msg) => {
    let log = writeToFile(enumMessageType.Log, file, method, msg)
    //console.log(log);
}

exports.info = (file, method, msg) => {
    let log = writeToFile(enumMessageType.Info, file, method, msg)
    //console.info(log);
}






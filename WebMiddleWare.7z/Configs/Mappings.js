//THIS FILE DEFINES ALL THE URLS USED THROUGHT OUT THE PROJECT

var Apis = {
    // //authentication: "https://gb04pm7.global.jhcn.net:443/XMII/IlluminatorOData/QueryTemplate?xsrfid=Fetch",
    // Andon Boards APIs
    cellUsers: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/andonboard/QMDO/QMDO_Cell_Users&Content-Type=text/json",
    cellStats: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/andonboard/QMDO/QMDO_Andonboard_Summary&Content-Type=text/json",
    arrears: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/andonboard/QMDO/QMDO_Arrears&Content-Type=text/json",
    outputVsBookings: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/andonboard/QMDO/QMDO_OutputVsBooking&Content-Type=text/json",
    ftprRtpy: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/andonboard/QMDO/QMDO_Cell_Ftpr_Rtpy&Content-Type=text/json",

    //Stator Trend APIs
    partsList: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_Dashboard_StatorTrend/Query/readPartNumberList&Content-Type=text/json&Param.1=",
    lastPartNumber: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_Dashboard_StatorTrend/MDO/readLastPartNumber&Content-Type=text/json&Param.1=",
    chartsData: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_Dashboard_StatorTrend/MDO/readStatorJoinData&Content-Type=text/json",

    //IS Data Transfer Monitor
    //Screen 1
    MiiJHWorksQueueCount: "https://gb04pm7.global.jhcn.net/XMII/Runner?Transaction=ZJH_WebMiddleWare/dataTransferMonitor/Transaction/TRANS_Monitoring_Stats&OutputParameter=output&Session=false&content-type=text/json",
    //Screen 2
    MiiQueueMessages: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/QMDO/MDO_GetMiiQueueMessages&Content-Type=text/json",
    JHWorksQueueMessages: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/SQL/GetJHWorksQueueMessages&Content-Type=text/json",
    //Screen 3
    NewProducts: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/SQL/GetNewProducts&Content-Type=text/json",
    UntransferredSNo: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/SQL/GetSerialsNotTransferred&Content-Type=text/json",
    TriggerSerialNo: "https://gb04pm7.global.jhcn.net/XMII/Runner?Transaction=ZJH_WebMiddleWare/dataTransferMonitor/Transaction/InboundTriggerSerialNumber&OutputParameter=message&Content-Type=text/json",
    //Screen4
    Report: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/QMDO/MDO_GetReportJHWorks&Content-Type=text/json",
    //
    Timers: "https://gb04pm7.global.jhcn.net/XMII/Illuminator?QueryTemplate=ZJH_WebMiddleWare/dataTransferMonitor/QMDO/QMDO_GetTimersStatus&Content-Type=text/json"
}

exports.GetAPIByKey = (key) => {
    //apis[key].endPoint =  apis[key].endPoint + (apis.token !== null ? '&xsrfid=' + apis.token : '');
    return Apis[key];
}
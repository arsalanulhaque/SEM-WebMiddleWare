//THIS FILE READS APPLICATION LEVEL VARIABLES FROM .env file.
//.env FILE SHOULD ALWAYS BE ROOT FOLDER OF THIS PROJECT

// config.js

//Method 1: This is to do manually by developer
//const dotenv = require('dotenv');
// dotenv.config();
// module.exports = {
//     UserName: process.env.UserName,
//     Password: process.env.Password,

// };


//Method 2: It is done by  NPM dotenv package
const dotenv = require('dotenv');
const result = dotenv.config();
if (result.error) {
  throw result.error;
}
const { parsed: envs } = result;
console.log(envs);
module.exports = envs;
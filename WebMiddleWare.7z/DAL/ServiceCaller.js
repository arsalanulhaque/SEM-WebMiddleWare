//THIS FILE HAS ALL THE REQUIRED CODE TO MAKE AN API CALL

//const https = require('https');
const axios = require("axios");
var authentication = require('../BLL/Authentication');
var logger = require('../Utilities/Logger')

//Forcefully disabling TLS rejections
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
//Accessing Authentication Header
let auth = new authentication.Authentication()

exports.ServiceCaller = async (url, callback) => {
    try {
        let headers = auth.getAuthHeader()
        headers.timeout = 60000

        //Sending https request
        axios.get(url + '&session=false', headers).then(response => {
            try {
                //sending back the response
                callback(response);
            }
            catch (error) {
                logger.error("ServiceCaller.js", 'ON RESPONSE FROM API (axios) ', error);
                callback(error);
            }
        }).catch(error => {
            logger.error("ServiceCaller.js", "ON API CALL ", error)
            callback(error);
        })
    }
    catch (error) {
        logger.error("ServiceCaller.js", "Error ON (ServiceCaller)  ", error);
        callback(error);
    }
}
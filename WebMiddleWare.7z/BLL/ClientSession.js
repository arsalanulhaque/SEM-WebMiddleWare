//THIS FILE IS USED TO MAINTAIN ClientSessions

const logger = require('../Utilities/Logger.js')

let clientSessionsPool = [];

class PriavteClientSession {
    constructor() { }
    //clientSessionsPool = [];

    getAllClientSessions() {
        return clientSessionsPool
    }

    getClientSessions(dashboardID) {
        return clientSessionsPool.filter((item) => { return item.dashboardID === dashboardID });
    }

    excludeClientSessions(dashboardID) {
        return clientSessionsPool.filter((item) => { return item.dashboardID !== dashboardID });
    }

    getClientCount() {
        return clientSessionsPool?.length
    }

    addClientSession(data) {
        try {
            let filterSocket = clientSessionsPool.find((item) => { return item.dashboardID === data.dashboardID && item.sessionID === data.sessionID });
            if (filterSocket !== undefined) {
                //if client already registered but with different socketID 
                //we need to remove the old session from session pools array
                filterSocket.socketID = data.socketID
            }
            //Adding  client session to pool
            if (filterSocket === undefined)
                clientSessionsPool.push(data)
        }
        catch (error) {
            logger.error("ClientSession.js", "addClientSession", error);
        }
    }

    removeClientBySocketID(socketID) {
        try {
            let filterSockets = clientSessionsPool.filter((item) => { return item.socketID === socketID });
            if (filterSockets !== undefined) {
                if (filterSockets.length > 0) {
                    filterSockets.map(instance => {
                        clientSessionsPool.pop(instance);
                    })
                }
            }
        }
        catch (error) {
            logger.error("ClientSession.js", "removeClientSession", error);
        }
    }

    updateClientSession(data) {
        try {
            let index = clientSessionsPool.findIndex((item) => { return item.dashboardID === data.dashboardID && item.sessionID === data.sessionID && item.socketID === data.socketID })
            if (index > -1) {
                clientSessionsPool[index] = data
            }
        }
        catch (error) {
            logger.error("ClientSession.js", "updateClientSession", error);
        }
    }
}

class ClientSession {
    constructor() {
        throw new Error('Use ClientSession.getInstance()');
    }
    static getInstance() {
        if (!ClientSession.instance) {
            ClientSession.instance = new PriavteClientSession();
        }
        return ClientSession.instance;
    }
}

module.exports.ClientSession = ClientSession;
//THIS FILE IS USED TO MAINTAIN API AUTHENTICATION 
//AND IS OF UTMOST IMPORTAMT

const { UserName, Password } = require('../Configs/ENV');

var callee = require('../DAL/ServiceCaller')
var mappings = require('../Configs/Mappings')
var logger = require('../Utilities/Logger')

class Authentication {
    GlobalToken = null;
    constructor() { }

    //Setting https request headers for Basic Auth
    //Will be used for all api calls in ServiceCaller.js
    getAuthHeader() {
        return {
            auth: {
                username: UserName,
                password: Password
            },
            xsrfid: this.getToken()
        }
    }

    setToken(token) {
        try {
            if (token === undefined || token === null) {
                logger.error("Authentication.js", "setToken", "Unable to get authentication token!")
                throw reportError('Unable to get authentication token!')
            }
            this.GlobalToken = token;
        }
        catch (error) {
            logger.error("Authentication.js", "setToken", error);
        }
    }

    getToken() {
        try {
            return this.GlobalToken;
        }
        catch (error) {
            logger.error("Authentication.js", "getToken", error);
        }
    }

    hasToken() {
        try {
            return this.GlobalToken === null || this.GlobalToken === undefined || this.GlobalToken.length === 0 ? false : true;
        }
        catch (error) {
            logger.error("Authentication.js", "hasToken", error);
        }
    }

    RequestToken() {
        try {
            if (!this.hasToken()) {
                callee.ServiceCaller(mappings.GetAPIByKey('authentication'), (response) => {
                    // let cookie = Buffer.from(response.headers['set-cookie'][3]).toString()
                    // cookie = cookie.slice(0, cookie.indexOf(';'))
                    // let params = `${response.headers.xsrfid}&${cookie}`;
                    // cookie.map((key, val) => {
                    //     params += `&${key}=${val}`
                    // })
                    this.setToken(response.headers.xsrfid)
                    logger.info("Authentication.js", "RequestToken", "TOKEN: " + this.getToken())
                })
            }
        }
        catch (error) {
            logger.error("Authentication.js", "RequestToken", error);
        }
    }
}

module.exports.Authentication = Authentication;
//THIS IS THE MAIN ENTRY FILE FOR THE PROJECT
//THE APPLICATION IS BASED ON NODEJS AND EXPRESS JS
//THIS APPLICATION SERVES AS THE SERVER FOR ANDON BOARD PROJECT

//TO RUN PROJECT USE THE COMMAND (node index.js) ON COMMAND PROMPT OR IN VS TERMINAL

try {

    const app = require('express')();
    const http = require('http').Server(app);
    const io = require('socket.io')(http, {
        cors: {
            origin: '*',
        }
    })
    const socketIO = require('./Controllers/SocketIO')
    const dataController = require('./Controllers/DataController')
    const dtmController = require('./Controllers/SemDataTransferMonitor/DTMController')
    const logger = require('./Utilities/Logger')


    let interval_clock, interval_data;
    //Express route
    app.get("/", (req, res) => {
        logger.info('index.js', 'app.get to route "/"', 'Incoming request to route "/"')
        //setting cors header
        res.set("Access-Control-Allow-Origin", "*");
        res.sendFile(__dirname + "/index.html")
    });

    app.get("/auth", async (req, res) => {
        logger.info('index.js', 'app.get to route "/auth"', 'Incoming request to route "/"')
        //setting cors header
        res.set("Access-Control-Allow-Origin", "*");
        let tokenVal = await dataController.GetToken().then(token => {
            return token;
        })
        res.send({ 'xsrfid': tokenVal })
    });

    app.get("/partsList/:id", async (req, res) => {
        logger.info('index.js', 'app.get to route "/partsList/:id"', 'Incoming request to route "/partsList/:id"')
        //setting cors header
        res.set("Access-Control-Allow-Origin", "*");

        dataController.GetPartsList(req.params.id, (data) => {
            res.send(data)
        })
    });

    app.get("/lastPartNumber/:id", async (req, res) => {
        logger.info('index.js', 'app.get to route "/lastPartNumber/:id"', 'Incoming request to route "/lastPartNumber/:id"')
        //setting cors header
        res.set("Access-Control-Allow-Origin", "*");
        dataController.GetLastPartNumber(req.params.id, (data) => {
            res.send(data)
        })
    });

    app.get("/chartsData", async (req, res) => {
        logger.info('index.js', 'app.get to route "/chartsData"', 'Incoming request to route "/chartsData"')
        //setting cors header
        res.set("Access-Control-Allow-Origin", "*");
        dataController.GetChartsData((data) => {
            res.send(data)
        })
    });

    //Initializing Socket Server
    socketIO.SocketServer(io, socketIO);

    // socketIO.io.on("ReqFilteredData", function (data) {
    //     console.log('Number of clients: ', socket.rooms)
    //     //io.sockets.in(data.room).emit('updateClientUrl', data);
    // })

    // Sending Clock time on every second
    interval_clock = setInterval(function () {
        io.sockets.emit('timerEvent', dataController.clock());
    }, 1000);

    //This is responsible to check new data from API 
    //sends an update to clients after every 5 seconds
    interval_data = setInterval(() => {
        if (socketIO.IsClientConnected()) {
            //Getting Cell Summary Data
            dataController.GetCellStats((result) => {
                //Calling Socket Event to Notify Client
                socketIO.NotifyClient('AndonBoards', 'cellStats', result)
            })

            //Getting List of Users Loggedin
            dataController.GetUserList((result) => {
                //Calling Socket Event to Notify Client
                socketIO.NotifyClient('AndonBoards', 'cellUsers', result)
            })

            //Getting Arrears 
            dataController.GetArrears((result) => {
                //Calling Socket Event to Notify Client
                socketIO.NotifyClient('AndonBoards', 'arrears', result)
            })

            //Getting OutputVsBookings 
            dataController.GetOutputVsBookings((result) => {
                //Calling Socket Event to Notify Client
                socketIO.NotifyClient('AndonBoards', 'outputVsBookings', result)
                socketIO.NotifyClient('AndonBoards', 'runningTargets', result)
                socketIO.NotifyClient('AndonBoards', 'efficiency', result)
            })

            //Getting FTPR & RTPY FOR CELL TABLE 
            dataController.GetFtprRtpy((result) => {
                //Calling Socket Event to Notify Client
                socketIO.NotifyClient('AndonBoards', 'FtprRtpy', result)
            })

            dtmController.Run(socketIO)
        }
    }, (1000 * 10));

    //Starting Application Server
    http.listen(process.env.PORT || 8001, function () {

        //This method is to connect with API
        //Needs to run only once for the Application Lifecycle
        //dataController.GenerateToken();
        console.info(`listening on *:(${process.env.PORT || 8001})`);
        logger.info('index.js', 'http.listen', `Server listening on *:(${process.env.PORT || 8001})`)
    });
}

catch (err) {
    logger.error('index.js', 'Application level error', err)
}